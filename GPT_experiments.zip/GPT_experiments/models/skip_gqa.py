import math
from dataclasses import dataclass
from typing import Optional, Tuple

import torch
import torch.nn.functional as F
from torch import nn

@dataclass
class ModelArgs:
    dim: int = 1024
    n_layers: int = 24
    n_heads: int = 16
    n_query_groups: int = 8  # 新增参数，Key 和 Value 的分组数
    vocab_size: int = 50257  # defined later by tokenizer
    multiple_of: int = 256  # make SwiGLU hidden layer size multiple of large power of 2
    norm_eps: float = 1e-5
    max_batch_size: int = 20
    max_seq_len: int = 1024

class RMSNorm(nn.Module):
    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        norm = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps)
        return norm * self.weight

def precompute_freqs_cis(dim: int, end: int, theta: float = 10000.0):
    freqs = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))
    t = torch.arange(end, device=freqs.device)
    freqs = torch.outer(t, freqs).float()
    freqs_cis = torch.polar(torch.ones_like(freqs), freqs)
    return freqs_cis

def apply_rotary_emb(x: torch.Tensor, freqs_cis: torch.Tensor) -> torch.Tensor:
    x_ = torch.view_as_complex(x.float().reshape(*x.shape[:-1], -1, 2))
    freqs_cis = freqs_cis.view(1, x.size(1), 1, x.size(-1) // 2)  # 动态调整形状
    x_out = torch.view_as_real(x_ * freqs_cis).flatten(3)
    return x_out.type_as(x)

class Attention(nn.Module):
    first_v = None
    def __init__(self, args: ModelArgs, layer_id: int):
        super().__init__()
        self.n_heads = args.n_heads  # Query 的头数
        self.layer_id = layer_id
        self.n_query_groups = args.n_query_groups  # Key 和 Value 的分组数
        self.head_dim = args.dim // self.n_heads
        self.group_dim = args.dim // self.n_heads  # 每个分组的维度
        self.scale = self.head_dim ** -0.5

        # Query 的头数保持不变
        self.wq = nn.Linear(args.dim, self.n_heads * self.head_dim, bias=False)
        # Key 和 Value 的头数变为 n_query_groups
        self.wk = nn.Linear(args.dim, self.n_query_groups * self.group_dim, bias=False)
        if layer_id == 0:
            self.wv = nn.Linear(args.dim, self.n_query_groups * self.group_dim, bias=False)
        else:
            self.wv = nn.Linear(args.dim, (self.n_query_groups // 2) * self.group_dim, bias=False)
        # 输出仍然基于 Query 的头数
        self.wo = nn.Linear(self.n_heads * self.head_dim, args.dim, bias=False)

        self.register_buffer("cache_k", torch.zeros(0, 0, self.n_query_groups, self.group_dim))
        self.register_buffer("cache_v", torch.zeros(0, 0, self.n_query_groups, self.group_dim))

    def forward(self, x: torch.Tensor, start_pos: int, freqs_cis_q: torch.Tensor, freqs_cis_k: torch.Tensor, mask: Optional[torch.Tensor]):
        bsz, seqlen, _ = x.shape

        # Query 的头数是 n_heads
        xq = self.wq(x).view(bsz, seqlen, self.n_heads, self.head_dim)
        # Key 和 Value 的头数是 n_query_groups
        xk = self.wk(x).view(bsz, seqlen, self.n_query_groups, self.group_dim)
        if self.layer_id == 0:
            xv = self.wv(x).view(bsz, seqlen, self.n_query_groups, self.group_dim)
            Attention.first_v = xv[:, :, (self.n_query_groups // 2):, :]  # 保存第一层的后一半 Value
        else:
            xv = self.wv(x).view(bsz, seqlen, (self.n_query_groups // 2), self.group_dim)
            xv = torch.cat([xv, Attention.first_v], dim=2)  # 替换后一半 Value

        # 应用 Rotary Embedding
        xq = apply_rotary_emb(xq, freqs_cis=freqs_cis_q)
        xk = apply_rotary_emb(xk, freqs_cis=freqs_cis_k)

        # 转置以便计算注意力
        xq = xq.transpose(1, 2)  # (bsz, n_heads, seqlen, head_dim)
        xk = xk.transpose(1, 2)  # (bsz, n_query_groups, seqlen, group_dim)
        xv = xv.transpose(1, 2)  # (bsz, n_query_groups, seqlen, group_dim)

        # 将 Key 和 Value 的分组扩展到 Query 的头数
        # xk = xk.repeat_interleave(self.n_heads // self.n_query_groups, dim=1)
        # xv = xv.repeat_interleave(self.n_heads // self.n_query_groups, dim=1)
        # 动态处理分组：将 Key 和 Value 映射到 Query 的头数
        scale_factor = self.n_heads // self.n_query_groups
        xk = xk.unsqueeze(1).expand(-1, scale_factor, -1, -1, -1).reshape(bsz, self.n_heads, seqlen, self.group_dim)
        xv = xv.unsqueeze(1).expand(-1, scale_factor, -1, -1, -1).reshape(bsz, self.n_heads, seqlen, self.group_dim)

        # 使用 Flash Attention 或普通 Attention
        output = torch.nn.functional.scaled_dot_product_attention(
            xq, xk, xv, attn_mask=None, dropout_p=0.0, is_causal=True
        )

        # 转置回原始形状并通过输出层
        output = output.transpose(1, 2).contiguous().view(bsz, seqlen, -1)
        return self.wo(output)

class FeedForward(nn.Module):
    def __init__(self, dim: int, hidden_dim: int):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden_dim, bias=False)
        self.w2 = nn.Linear(hidden_dim, dim, bias=False)
        self.w3 = nn.Linear(dim, hidden_dim, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))

class TransformerBlock(nn.Module):
    def __init__(self, layer_id: int, args: ModelArgs):
        super().__init__()
        hidden_dim=4 * args.dim
        hidden_dim = int(2 * hidden_dim / 3)
        hidden_dim = args.multiple_of * ((hidden_dim + args.multiple_of - 1) // args.multiple_of)
        self.attention = Attention(args, layer_id)
        # self.feed_forward = FeedForward(dim=args.dim, hidden_dim=4 * args.dim)
        self.feed_forward = FeedForward(dim=args.dim, hidden_dim=hidden_dim)
        self.attention_norm = nn.LayerNorm(args.dim)
        self.ffn_norm = nn.LayerNorm(args.dim)

    def forward(self, x: torch.Tensor, start_pos: int, freqs_cis_q: torch.Tensor, freqs_cis_k: torch.Tensor, mask: Optional[torch.Tensor]):
        x = x + self.attention(self.attention_norm(x), start_pos, freqs_cis_q, freqs_cis_k, mask)
        x = x + self.feed_forward(self.ffn_norm(x))
        return x

class Transformer(nn.Module):
    def __init__(self, params: ModelArgs):
        super().__init__()
        self.params = params
        self.vocab_size = params.vocab_size
        self.n_layers = params.n_layers

        self.tok_embeddings = nn.Embedding(params.vocab_size, params.dim)

        self.layers = nn.ModuleList()
        for layer_id in range(params.n_layers):
            self.layers.append(TransformerBlock(layer_id, params))

        self.norm = nn.LayerNorm(params.dim)
        self.output = nn.Linear(params.dim, params.vocab_size, bias=False)
        
        self.output.weight = self.tok_embeddings.weight

        self.freqs_cis_q = precompute_freqs_cis(params.dim // params.n_heads, params.max_seq_len * 2)
        self.freqs_cis_k = precompute_freqs_cis(params.dim * (params.n_query_groups / params.n_heads) // params.n_query_groups, params.max_seq_len * 2)
        # self.freqs_cis = precompute_freqs_cis(params.dim // params.n_heads, params.max_seq_len)
        
        # 参数初始化
        self._init_weights()

    def _init_weights(self):
        def init(module):
            if isinstance(module, nn.Linear):
                nn.init.normal_(module.weight, std=0.02)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)
            elif isinstance(module, nn.Embedding):
                nn.init.normal_(module.weight, std=0.02)
            elif isinstance(module, RMSNorm):
                nn.init.ones_(module.weight)
        self.apply(init)

    def forward(self, tokens: torch.Tensor, start_pos: int = 0):
        _bsz, seqlen = tokens.shape
        h = self.tok_embeddings(tokens)
        self.freqs_cis_q = self.freqs_cis_q.to(h.device)
        self.freqs_cis_k = self.freqs_cis_k.to(h.device)
        freqs_cis_q = self.freqs_cis_q[start_pos:start_pos + seqlen]
        freqs_cis_k = self.freqs_cis_k[start_pos:start_pos + seqlen]

        mask = None
        # if seqlen > 1:
        #     mask = torch.full((seqlen, seqlen), float("-inf"), device=tokens.device)
        #     mask = torch.triu(mask, diagonal=1)
        #     mask = torch.hstack([torch.zeros((seqlen, start_pos), device=tokens.device), mask]).type_as(h)

        for layer in self.layers:
            h = layer(h, start_pos, freqs_cis_q, freqs_cis_k, mask)
        h = self.norm(h)
        output = self.output(h).float()
        return output
    
    def crop_sequence_length(self, sequence_length):
        # model surgery to decrease the block size if necessary
        # e.g. we may load the GPT2 pretrained model checkpoint (block size 1024)
        # but want to use a smaller block size for some smaller, simpler model
        assert sequence_length <= self.config.sequence_length
        self.config.sequence_length = sequence_length
        for block in self.transformer.h:
            block.attn.bias = block.attn.bias[:,:,:sequence_length,:sequence_length]

    @classmethod
    def from_pretrained(cls, model_type, override_args=None):
        # TODO
        pass

    def get_parameter_group_specs(self):
        """
        This long function is unfortunately doing something very simple and is being very defensive:
        We are separating out all parameters of the model into two buckets: those that will experience
        weight decay for regularization and those that won't (biases, and layernorm/embedding weights).
        We are then returning the PyTorch optimizer object.
        """

        # separate out all parameters to those that will and won't experience regularizing weight decay
        decay = set()
        no_decay = set()
        whitelist_weight_modules = (torch.nn.Linear, )
        blacklist_weight_modules = (torch.nn.LayerNorm, RMSNorm, torch.nn.Embedding)
        for mn, m in self.named_modules():
            for pn, p in m.named_parameters():
                fpn = '%s.%s' % (mn, pn) if mn else pn # full param name
                # random note: because named_modules and named_parameters are recursive
                # we will see the same tensors p many many times. but doing it this way
                # allows us to know which parent module any tensor p belongs to...
                if pn.endswith('bias'):
                    # all biases will not be decayed
                    no_decay.add(fpn)
                elif pn.endswith('weight') and isinstance(m, whitelist_weight_modules):
                    # weights of whitelist modules will be weight decayed
                    decay.add(fpn)
                elif pn.endswith('weight') and isinstance(m, blacklist_weight_modules):
                    # weights of blacklist modules will NOT be weight decayed
                    no_decay.add(fpn)

        # subtle: 'transformer.wte.weight' and 'lm_head.weight' are tied, so they
        # will appear in the no_decay and decay sets respectively after the above.
        # In addition, because named_parameters() doesn't return duplicates, it
        # will only return the first occurence, key'd by 'transformer.wte.weight', below.
        # so let's manually remove 'lm_head.weight' from decay set. This will include
        # this tensor into optimization via transformer.wte.weight only, and not decayed.
        decay.remove('output.weight')

        # validate that we considered every parameter
        param_dict = {pn: p for pn, p in self.named_parameters()}
        inter_params = decay & no_decay
        union_params = decay | no_decay
        assert len(inter_params) == 0, "parameters %s made it into both decay/no_decay sets!" % (str(inter_params), )
        assert len(param_dict.keys() - union_params) == 0, "parameters %s were not separated into either decay/no_decay set!" \
                                                    % (str(param_dict.keys() - union_params), )

        # create the pytorch optimizer object
        return [
            {"params": sorted(list(decay))},
            {"params": sorted(list(no_decay)), "weight_decay": 0.0},
        ]

    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, top_k=None):
        """
        Take a conditioning sequence of indices idx (LongTensor of shape (b,t)) and complete
        the sequence max_new_tokens times, feeding the predictions back into the model each time.
        Most likely you'll want to make sure to be in model.eval() mode of operation for this.
        """
        for _ in range(max_new_tokens):
            # if the sequence context is growing too long we must crop it at sequence_length
            idx_cond = idx if idx.size(1) <= self.config.sequence_length else idx[:, -self.config.sequence_length:]
            # forward the model to get the logits for the index in the sequence
            logits = self(idx_cond, get_logits=True)['logits']
            # pluck the logits at the final step and scale by desired temperature
            logits = logits[:, -1, :] / temperature
            # optionally crop the logits to only the top k options
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float('Inf')
            # apply softmax to convert logits to (normalized) probabilities
            probs = F.softmax(logits, dim=-1)
            # sample from the distribution
            idx_next = torch.multinomial(probs, num_samples=1)
            # append sampled index to the running sequence and continue
            idx = torch.cat((idx, idx_next), dim=1)

        return idx
    
    @torch.no_grad()
    def generate_from_string(self, in_str, max_new_tokens, temperature=1.0, top_k=None):
        idx = torch.tensor(self.tokenizer.encode(in_str, allowed_special={"<|endoftext|>"})).view(1,-1).to(self.lm_head.weight.device)
        out_idx = self.generate(idx, max_new_tokens, temperature, top_k).view(-1).to('cpu').numpy()
        return self.tokenizer.decode(out_idx)