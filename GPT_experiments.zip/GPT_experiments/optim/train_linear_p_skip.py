from contextlib import nullcontext

import torch
import torch.nn as nn
import torch.nn.functional as F
import wandb
import time 
import copy
import traceback
import transformers

from .utils import eval, get_batch, save_checkpoint

@torch.no_grad()
def eval_with_linear_probe(model, layer_norm, linear_head, data_tensor, sequence_length, batch_size, block_id, device='cpu', max_num_batches=24, ctx=nullcontext()):
    """
    对指定 block 的 LayerNorm 和线性头进行评估，支持 SkipFormer2 的 prev_v_list 逻辑。

    Args:
        model: 预训练好的 GPT 模型实例。
        layer_norm: 指定 block 的 LayerNorm。
        linear_head: 指定 block 的线性头。
        data_tensor: 数据张量。
        sequence_length: 序列长度。
        batch_size: 每个 batch 的大小。
        block_id: 指定的 block ID。
        device: 设备（'cpu' 或 'cuda'）。
        max_num_batches: 最大评估批次数。
        ctx: 上下文管理器（如 AMP 的 autocast）。

    Returns:
        val_acc_list: 验证集准确率列表。
        val_loss_list: 验证集 loss 列表。
        val_perplexity_list: 验证集困惑度列表。
    """
    assert model.training == False

    val_loss_list, val_acc_list, val_perplexity_list = [], [], []

    for _ in range(max_num_batches):
        x, y = get_batch(data_tensor, sequence_length, batch_size, device=device)
        with ctx:
            # 获取 token 和位置嵌入
            idx, pos_emb_closure = model.transformer.wpe(x)
            tok_emb = model.transformer.wte(idx)  # token embeddings
            x = pos_emb_closure.adapt_model_input(tok_emb)
            x = model.transformer.drop(x)

            # 初始化 prev_v_list
            prev_v_list = []

            # 前向传播到指定 block
            for i, block in enumerate(model.transformer.h):
                x, prev_v_list = block(x, pos_emb_closure, cache_context=None, start_index=0, prev_v_list=prev_v_list)
                if i == block_id:  # 计算到指定 block_id 后停止
                    break

            # 对指定 block 的输出进行 linear probe
            normed_x = layer_norm(x)  # 通过 LayerNorm
            logits = linear_head(normed_x)  # 通过线性头

            # 计算 loss 和准确率
            val_loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1), ignore_index=-1)
            val_acc = (logits.argmax(-1) == y).float().mean().item()
            val_perplexity = 2.71828 ** val_loss.item()

            # 存储结果
            val_loss_list.append(val_loss.item())
            val_acc_list.append(val_acc)
            val_perplexity_list.append(val_perplexity)

    return val_acc_list, val_loss_list, val_perplexity_list

def train_linear_probe(model, data, config, iterations, acc_steps, batch_size, sequence_length, eval_freq, block_id, extra_args, lr=1e-3):
    """
    训练指定 block 的 LayerNorm 和线性头，冻结模型其他参数。

    Args:
        model: GPT 模型实例。
        data: 数据字典，包含 'train' 和 'val' 数据。
        config: 模型配置，包含 n_embd 和 vocab_size 等信息。
        iterations: 总训练迭代次数。
        acc_steps: 梯度累积步数。
        batch_size: 每个 batch 的大小。
        sequence_length: 序列长度。
        eval_freq: 每隔多少步进行一次评估。
        block_id: 指定的 block ID。
        extra_args: 额外参数，包含设备信息等。
        lr: 学习率。

    Returns:
        stats: 训练和验证的统计信息。
    """
    device_type = 'cuda' if 'cuda' in str(extra_args.device) else 'cpu'
    type_ctx = nullcontext() if device_type == 'cpu' else torch.amp.autocast(
        device_type=device_type, dtype=extra_args.dtype)
    itr, substep, best_val_loss = 0, 0, float('inf')

    stats = {'train_loss': [], 'val_loss': [], 'val_pp': [], 'val_acc': []}

    # 冻结模型参数
    for param in model.parameters():
        param.requires_grad = False

    # 初始化指定 block 的 LayerNorm 和线性头
    # layer_norm = nn.LayerNorm(config.n_embd, bias=False).to(extra_args.device)
    # linear_head = nn.Linear(config.n_embd, config.vocab_size, bias=False).to(extra_args.device)
    # 初始化指定 block 的 LayerNorm 和线性头
    layer_norm = nn.LayerNorm(config.n_embd, bias=False).to(extra_args.device)
    linear_head = nn.Linear(config.n_embd, config.vocab_size, bias=False).to(extra_args.device)

    # 将权重初始化为模型的最后一层 LayerNorm 和 lm_head 的权重
    with torch.no_grad():
        layer_norm.weight.copy_(model.transformer.ln_f.weight)
        linear_head.weight.copy_(model.lm_head.weight)

    # 确保这些层的参数是可训练的
    for param in layer_norm.parameters():
        param.requires_grad = True
    for param in linear_head.parameters():
        param.requires_grad = True

    # 使用单个优化器
    # optimizer = torch.optim.Adam(list(layer_norm.parameters()) + list(linear_head.parameters()), lr=lr)
    optimizer = transformers.optimization.AdamW(list(layer_norm.parameters()) + list(linear_head.parameters()), lr=lr, betas=(config.beta1, config.beta2), weight_decay=config.weight_decay)

    # 添加学习率调度器
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer=optimizer,
        max_lr=lr,
        total_steps=iterations,
        pct_start=0.1,  # 前 10% 的迭代用于学习率升高
        anneal_strategy='linear',  # 学习率线性下降
        cycle_momentum=False,
        div_factor=1e2,
        final_div_factor=0.1
    )

    model.eval()  # 冻结的模型部分不需要训练模式
    # 在训练开始前进行初始评估
    val_acc_list, val_loss_list, val_perplexity_list = eval_with_linear_probe(
        model=model,
        layer_norm=layer_norm,
        linear_head=linear_head,
        data_tensor=data['val'],
        sequence_length=sequence_length,
        batch_size=batch_size,
        block_id=block_id,
        device=extra_args.device,
        max_num_batches=64,
        ctx=type_ctx
    )

    # 打印初始评估结果
    print(f"Initial: [val] loss={sum(val_loss_list)/len(val_loss_list):.3f}, "
        f"pp={sum(val_perplexity_list)/len(val_perplexity_list):.2f}, "
        f"acc={sum(val_acc_list)/len(val_acc_list):.3f}")
    
    model.eval()  # 冻结的模型部分不需要训练模式

    t0 = time.time()
    while itr < iterations:
        for microstep_idx in range(acc_steps):  # 梯度累积
            x, y = get_batch(data['train'], sequence_length, batch_size, device=extra_args.device)
            with type_ctx:
                # 前向传播到指定 block
                idx, pos_emb_closure = model.transformer.wpe(x)
                tok_emb = model.transformer.wte(idx)  # token embeddings
                x = pos_emb_closure.adapt_model_input(tok_emb)
                x = model.transformer.drop(x)

                # 初始化 prev_v_list
                prev_v_list = []

                for i, block in enumerate(model.transformer.h):
                    x, prev_v_list = block(x, pos_emb_closure, cache_context=None, start_index=0, prev_v_list=prev_v_list)
                    if i == block_id:  # 计算完 block_id 块的输出后停止
                        break

                # 对指定 block 的输出进行 linear probe
                normed_x = layer_norm(x)  # 通过 LayerNorm
                logits = linear_head(normed_x)  # 通过线性头

                # 计算 loss
                loss = F.cross_entropy(logits.view(-1, logits.size(-1)), y.view(-1), ignore_index=-1)
                loss.backward()

            substep += 1

        # 梯度裁剪
        if extra_args.grad_clip != 0.0:
            torch.nn.utils.clip_grad_norm_(list(layer_norm.parameters()) + list(linear_head.parameters()), extra_args.grad_clip)

        # 优化参数
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)

        # 更新学习率
        scheduler.step()

        itr += 1

        # 评估
        if itr % eval_freq == 0 or itr == iterations:
            val_acc_list, val_loss_list, val_perplexity_list = eval_with_linear_probe(
                model=model,
                layer_norm=layer_norm,
                linear_head=linear_head,
                data_tensor=data['val'],
                sequence_length=sequence_length,
                batch_size=batch_size,
                block_id=block_id,
                device=extra_args.device,
                max_num_batches=64,
                ctx=type_ctx
            )
            # 打印平均值
            print(f"Iteration {itr}: [val] loss={sum(val_loss_list)/len(val_loss_list):.3f}, "
                  f"pp={sum(val_perplexity_list)/len(val_perplexity_list):.2f}, "
                  f"acc={sum(val_acc_list)/len(val_acc_list):.3f}")
            stats['val_loss'].append(sum(val_loss_list) / len(val_loss_list))
            stats['val_pp'].append(sum(val_perplexity_list) / len(val_perplexity_list))
            stats['val_acc'].append(sum(val_acc_list) / len(val_acc_list))

            t1 = time.time()
            print(f"Time per iteration: {(t1 - t0) * 1000 / eval_freq:.2f}ms")
            t0 = time.time()

    return stats