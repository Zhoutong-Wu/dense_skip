# Copyright 2023 Matteo Pagliardini, Amirkeivan Mohtashami, Francois Fleuret, Martin Jaggi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import torch
import torch.nn.functional as F
from contextlib import nullcontext, contextmanager, ExitStack


def get_batch(data, seq_length, batch_size, device='cpu'):
    ix = torch.randint(len(data) - seq_length - 1, (batch_size,))
    x = torch.stack([torch.from_numpy((data[i:i+seq_length]).astype(np.int64)) for i in ix])
    y = torch.stack([torch.from_numpy((data[i+1:i+1+seq_length]).astype(np.int64)) for i in ix])
    if device != 'cpu':
        # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
        x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    return x, y

# def get_batch(data, seq_length, batch_size, device='cpu'):
#     print(f'data length:{len(data)}')
#     print(f'sequence length:{seq_length}')
#     print(f'batch size:{batch_size}')
    
#     # 确保 ix 都是偶数
#     ix = 2 * torch.randint((len(data) - 2 * seq_length) // 2, (batch_size,))
    
#     # 从 i:i+2*seq_length 取 x
#     x = torch.stack([data[i][0:2*seq_length:2].float() for i in ix])
#     # 从 i+1:i+2*seq_length:2 取 y
#     y = torch.stack([data[i][1:2*seq_length:2].float() for i in ix])
#     # # 从 i:i+2*seq_length 取 x
#     # x = torch.stack([torch.from_numpy((data[i:i+2*seq_length:2]).astype(np.float32)) for i in ix])
#     # # 从 i+1:i+2*seq_length:2 取 y
#     # y = torch.stack([torch.from_numpy((data[i+1:i+2*seq_length:2]).astype(np.float32)) for i in ix])
    
#     if device != 'cpu':
#         # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
#         x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    
#     return x, y

# def get_batch(data_loader, seq_length, batch_size, device='cpu'):
#     print(f'sequence length: {seq_length}')
#     print(f'batch size: {batch_size}')
    
#     # 从 DataLoader 中获取一个批次的数据
#     data_iter = iter(data_loader)
#     batch = next(data_iter)
#     print(f'data length:{len(batch)}')
    
#     # 确保 ix 都是偶数
#     ix = 2 * torch.randint((len(batch) - 2 * seq_length) // 2, (batch_size,))
    
#     # 从 i:i+2*seq_length 取 x
#     x = torch.stack([batch[i:i+2*seq_length:2].float() for i in ix])
#     # 从 i+1:i+2*seq_length:2 取 y
#     y = torch.stack([batch[i+1:i+2*seq_length:2].float() for i in ix])
    
#     if device != 'cpu':
#         # pin arrays x,y, which allows us to move them to GPU asynchronously (non_blocking=True)
#         x, y = x.pin_memory().to(device, non_blocking=True), y.pin_memory().to(device, non_blocking=True)
    
#     return x, y


@torch.no_grad()
def eval(model, data_tensor, sequence_length, batch_size, device='cpu', max_num_batches=24, ctx=nullcontext()):
    assert model.training == False

    loss_list_val, acc_list = [], []

    for _ in range(max_num_batches): 
        x, y = get_batch(data_tensor, sequence_length, batch_size, device=device)
        with ctx:
            outputs = model(x, targets=y, get_logits=True)
        val_loss = outputs['loss']
        loss_list_val.append(val_loss)
        acc_list.append((outputs['logits'].argmax(-1) == y).float().mean())

    val_acc = torch.stack(acc_list).mean().item()
    val_loss = torch.stack(loss_list_val).mean().item()
    val_perplexity = 2.71828 ** val_loss
    # val_perplexity = val_loss

    return val_acc, val_loss, val_perplexity

def save_checkpoint(distributed_backend, model, opt, scheduler, itr, ckpt_path, **extra_args):

    checkpoint = dict({
        'model': distributed_backend.get_raw_model(model).state_dict(),
        'optimizer': opt.state_dict(),
        'scheduler': scheduler.state_dict(),
        'itr': itr,
    }, **extra_args)

    torch.save(checkpoint, ckpt_path)
